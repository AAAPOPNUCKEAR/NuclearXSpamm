<h1 align="center"><b>⚠️⚜️𝗡𝘂𝗰𝗹𝗲𝗮𝗿𝗫𝘀𝗽𝗮𝗺⚜️⚠️</b></h1>

<h4 align="center"> 𝗙𝗮𝘀𝘁 𝘀𝗽𝗮𝗺 𝘂𝘀𝗲𝗿𝗯𝗼𝘁</h4>

<p align="center"><a href="https://t.me/NucLeaR_xD"><img src="https://te.legra.ph/file/cd03811f7b0f90d7fc690.jpg" width="400"></a></p>


> ⭐️ 𝘁𝗵𝗮𝗻𝗸𝘀 𝗲𝘃𝗲𝗿𝘆𝗼𝗻𝗲 𝗳𝗼𝗿 𝘂𝘀𝗶𝗻𝗴 𝘁𝗵𝗶𝘀 𝗽𝗼𝘄𝗲𝗿𝗳𝘂𝗹 𝗡𝘂𝗰𝗹𝗲𝗮𝗿 𝘅 𝘀𝗽𝗮𝗺 𝘂𝘀𝗲𝗿𝗯𝗼𝘁 𝗱𝗲𝗽𝗹𝗼𝘆 𝗶𝘁 𝗮𝗻𝗱 𝗲𝗻𝗷𝗼𝘆!
 
    ♡︎𝐅𝐚𝐬𝐭 𝐚𝐧𝐝 𝐏𝐨𝐰𝐞𝐫𝐟𝐮𝐥 𝐬𝐩𝐚𝐦 𝐛𝐨𝐭😈

♡︎𝐃𝐞𝐩𝐥𝐨𝐲 𝐛𝐨𝐭 𝐮𝐬𝐢𝐧𝐠 𝐛𝐨𝐭𝐟𝐚𝐭𝐡𝐞𝐫 𝐛𝐨𝐭 𝐭𝐨𝐤𝐞𝐧🤩

♡︎𝐃𝐞𝐩𝐥𝐨𝐲 10 𝐛𝐨𝐭𝐬 𝐢𝐧 𝐨𝐧𝐞 𝐭𝐢𝐦𝐞🤤

♡︎𝐒𝐨𝐧𝐠 𝐫𝐚𝐢𝐝 +𝐒𝐩𝐚𝐦 𝐛𝐨𝐭🥳

# ᴅᴇᴘʟᴏʏᴍᴇɴᴛ


<details>
<summary><b>ᴅᴇᴘʟᴏʏ ᴛᴏ ʜᴇʀᴏᴋᴜ</b></summary>
<br>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/ERR0rMK/SEMXxBOTFATHER)
  
</details>


# Owner And Credit


<details>
<summary><b>ᴄʀᴇᴅɪᴛ</b></summary>
<br>

</details>

<details>
<summary><b>sᴜᴘᴘᴏʀᴛ</b></summary>
<br>

# ꜱᴜᴘᴘᴏʀᴛ ✨
<a href="https://t.me/AUKAATMEINRAHO"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>

</details>
